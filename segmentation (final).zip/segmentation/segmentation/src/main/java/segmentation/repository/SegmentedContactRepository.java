package segmentation.repository;
 
import org.springframework.data.jpa.repository.JpaRepository;
import segmentation.model.SegmentedContact;
 
public interface SegmentedContactRepository extends JpaRepository<SegmentedContact, Long> {
}
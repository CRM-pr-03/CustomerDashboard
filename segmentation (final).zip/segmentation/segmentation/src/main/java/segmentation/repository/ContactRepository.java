
package segmentation.repository;
 
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import segmentation.model.Contact;
 
public interface ContactRepository extends JpaRepository<Contact, Long> {
    List<Contact> findByCategory(String category);
    List<Contact> findByCountry(String country);
    List<Contact> findByDateCreatedBetween(Date fromDate, Date toDate);
}
 


 
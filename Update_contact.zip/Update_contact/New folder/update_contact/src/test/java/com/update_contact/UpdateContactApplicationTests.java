package com.update_contact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateContactApplicationTests {

	@Test
	void contextLoads() {
	}

}

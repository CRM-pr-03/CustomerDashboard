package addcontact.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import addcontact.model.AddContact;
import addcontact.service.AddContactService;

@RestController
@RequestMapping("/api/contacts")
public class AddContactController {

    @Autowired
    private AddContactService addContactService;

    @PostMapping("/addcontacts")
    public ResponseEntity<AddContact> addContact(@RequestBody AddContact addContact) {
        // Implement validation or other business logic if required
        AddContact newContact = addContactService.addContact(addContact);
        return new ResponseEntity<>(newContact, HttpStatus.CREATED);
    }
}


package addcontact.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import addcontact.model.AddContact;

public interface AddContactRepository extends JpaRepository<AddContact, Long> {
    // You can add custom query methods here if needed
}

package addcontact.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import addcontact.model.AddContact;
import addcontact.repository.AddContactRepository;

@Service
public class AddContactService {

    @Autowired
    private AddContactRepository addContactRepository;

	public AddContact addContact(AddContact addContact) {
		
		return addContactRepository.save(addContact);
	}
 
    // Add method to add contact, update, delete, or other business logic as needed...
}

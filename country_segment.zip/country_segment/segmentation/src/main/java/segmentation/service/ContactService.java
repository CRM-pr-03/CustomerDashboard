package segmentation.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import segmentation.model.Contact;
import segmentation.repository.ContactRepository;

import java.util.List;

@Service
public class ContactService {
    @Autowired
    private ContactRepository contactRepository;
    
    public List<Contact> segmentContactsByCountry(String country) {
        return contactRepository.findByCountry(country);
    }
}
